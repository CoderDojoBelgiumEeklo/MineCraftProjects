# MineCraftProjects
repository voor de minecraft projecten


Hier vind u een webpagina met de [Opdrachten](http://CoderDojoBelgiumEeklo.github.io/MineCraftProjects)