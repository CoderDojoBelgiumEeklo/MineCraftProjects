export interface  ILanguage {
  id: number;
  value: string;
  abbreviation: string;
}
