export interface ITranslation {
  TranslationId: number;
  Value: string;
}
