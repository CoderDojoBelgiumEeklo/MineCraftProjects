export interface CarouselItem {
  url: string;
}
