#CoderDojo


![coderdojo](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/assets/brand.png?raw=true)


[coderdojo](https://www.coderdojobelgium.be/nl)


Welkom bij de startpagina van deze site. Aan de rechterkant ziet u de verschillende secties die u kunt raadplegen.
