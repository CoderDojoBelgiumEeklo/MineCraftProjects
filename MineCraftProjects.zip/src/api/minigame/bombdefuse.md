#Minigame Bomb defuse

### Designed by Mumbo Jumbo [YouTube video](https://www.youtube.com/watch?v=s_jyaJx0Vzg)

