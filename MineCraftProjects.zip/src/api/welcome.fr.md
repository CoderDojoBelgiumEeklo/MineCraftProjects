#CoderDojo


![coderdojo](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/assets/brand.png?raw=true)


[coderdojo](https://www.coderdojobelgium.be/fr)

