#CoderDojo


![coderdojo](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/assets/brand.png?raw=true)


[coderdojo](https://www.coderdojobelgium.be/en)


Welcome to the start page of this site. On the right you can see the different sections you can consult.
