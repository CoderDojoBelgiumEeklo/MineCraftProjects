# Twitch App launcher

%cstart%
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/redstone/comparatorClock.png?raw=true,
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/redstone/comparatorClock2.png?raw=true,
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/src/assets/logic/circuit/comparatorClock.png?raw=true, +
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/src/assets/logic/circuit/comparatorClock2.png?raw=true +
%cend%

##Welkom

Tijdens de oefeningen van Minecraft maken we gebruik van de Twitch app.  
Dit pakket wordt gebruikt om de CoderDOjo minecraft editie op te starten.   
Hieronder vindt u de uitleg om het pakket te downloaden.

##De Twitch App launcher

Voor gebruik te kunnen maken van de TwitchApp moet men een gratis twitchaccount maken.  
Dit is **niet** uw minecraft account.

##De CoderDojo Minecraft Modpack
Start de twitch app (vroeger de curse app).  
Je krijgt het volgende scherm te zien:

![Twitchstart](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/TwitchStart.png?raw=true)
  
Selecteer het minecraft symbool. (creeper gezicht).

![TwitchCreeper](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/Modpacks.png?raw=true)
  
Klik op de knop 'Browse All' Modpacks.  

![BrowseModpacks](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/BrowseModpacks.png?raw=true)
  
Type in de 'Search' links bovenaan het woord 'coderdoj'

![BrowseModpacks](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/Modpackselection.png?raw=true)

Je zal de modpack zien verschijnen die is aangemaakt voor CoderDojo Eeklo.  
Dit is een all-in-pack dat we gaan gebruiken om verschillende mods aan te leren (allemaal op een of andere manier gelinkt aan programen).  
Installeer dit pakket in uw profiel.

![BrowseModpacks](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/Modpackselection2.png?raw=true)

Wachten even tot het packet geinstalleerd is.

![BrowseModpacks](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/ModpackSelection3.png?raw=true)

Eenmaal installatie klaar is kunnen we het spel opstarten.

![BrowseModpacks](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/ModpackSelection4.png?raw=true)

Laat spel opstarten (dit kan even duren).  
Eenmaal het spel opgestart is zal men de volgende foto zien verschijnen."

![BrowseModpacks](https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/curse/background.png?raw=true)


%cstart%
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/redstone/comparatorClock.png?raw=true,
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/img/basic/redstone/comparatorClock2.png?raw=true,
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/src/assets/logic/circuit/comparatorClock.png?raw=true, +
https://github.com/CoderDojoBelgiumEeklo/MineCraftProjects/blob/gh-pages/src/assets/logic/circuit/comparatorClock2.png?raw=true +
%cend%
