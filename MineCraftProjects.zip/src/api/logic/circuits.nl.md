#Poorten & circuits


Met redstone kunnen we veel zaken bereiken.  
Maar om deze  doelen te bereieken hebbe, we nood aan een par basis circuits
Een van de dingen die we kunnen dunnen is het maken van circuits.
         
Deze circuits zijn mechanismes die altijd hetzelfd reageren.

Hieronder een overzicht van een paar verschillende circuits.  
Voor het gemak van uitleg hanteren we deze regels.  

##Legende
Blauw is ingang 1  
Oranje is ingang 2  
Rood is de uitgang  

##voorbeelden
    
Logische Poorten:                       
- En poort              (And-gate)      
- Of Poort              (Or-gate)       
- Niet poort            {Not-gate}      
- N-en (niet en) poort  (Nand-gate)     
- N-of (niet of) poort  (N0r-Gate       
                                                                                
Geavanceerdere circuits:     
- Bud switch,   
- Redstone klokken,    
- Monostabiel circuits,    
- bistabiel circtuit,    
- Randomizer,    
- Puls extenders,     
- Counter,    

