#De puls verlenger.

De puls verlenger is een een redstone circuit gemaakt om een redstone signaal te verlengen als de krachtbon wegis.

Een mooi voorbeeld hiervan is een drukknop.
Maak het volgende circuit

[Image]


Als je het test zal je zien dat signaal stapsgewijs lager word.

